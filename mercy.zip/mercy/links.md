Link 1 

https://www.figma.com/file/Td9qjMtZ8ZqO6kiE9oVQ90/UI%2FUX-Task1


link 2

https://www.figma.com/file/HtySluv0xF75GWhr5jry1J/UI-UX-Task2

link 3
https://www.figma.com/file/8BrPzRmHGfDS6sVIqtc33f/UI-UX-Task3


link 4

https://www.figma.com/file/Fjp1DWUnRzTckeVAidt9ux/UI%2FUX-Task4?node-id=0%3A1

link 5

https://www.figma.com/file/aJfGja20hcZ3mJ8OTeMvKr/UI%2FUX-Task5?node-id=0%3A1
