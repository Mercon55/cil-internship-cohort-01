import boto3
def lambda_handler(event, context):
    print("This is a lambda function created from Coudformation")
    return "Success"